import random
class Agent:
  def __init__(self):
    pass

  def choose_action(self, obs):
    return random.randint(0, 7)